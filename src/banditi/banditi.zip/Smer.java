package banditi;

public enum Smer {
	ISPRED, IZA;
}
