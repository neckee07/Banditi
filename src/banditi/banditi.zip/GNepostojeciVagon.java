package banditi;

public class GNepostojeciVagon extends Exception {

	public GNepostojeciVagon(String s) {
		super(s);
	}
	
}
