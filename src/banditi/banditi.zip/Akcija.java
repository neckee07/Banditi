package banditi;

public abstract class Akcija {

	
	protected Kompozicija kompozicija;
	
	
	
	public Akcija(Kompozicija kompozicija) {
		super();
		this.kompozicija = kompozicija;
	}



	public void izvrsi(Bandit dohvatiBandita) {
		// TODO Auto-generated method stub
		
	}

}
